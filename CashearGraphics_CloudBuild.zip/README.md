# Cashear Graphics

A real Android photo-editing app project.

## Build the APK using only your phone

This project includes a GitHub Actions cloud build.

1. Create/sign in to a GitHub account.
2. Create a new repository, for example `CashearGraphics`.
3. Upload ALL files and folders from this project to the repository.
4. Open the repository's **Actions** tab.
5. Select **Build Cashear Graphics APK**.
6. Tap **Run workflow** (or push to the `main` branch).
7. Wait for the build to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download **Cashear-Graphics-APK**.
10. Extract the downloaded ZIP. Inside is `app-debug.apk`.
11. Tap the APK to install it on your Android phone.

The cloud workflow builds a debug APK; it is suitable for installing and testing your app on your own phone.

## Current app features

- Choose a photo
- Brighten photo
- Grayscale filter
- Add text
- Reset edits
- Save edited photo to the gallery

## Important

The APK is not generated inside this ZIP. GitHub Actions generates it in the cloud after you upload the project.
