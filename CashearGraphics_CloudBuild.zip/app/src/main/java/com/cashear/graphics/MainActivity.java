package com.cashear.graphics;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.OutputStream;

public class MainActivity extends Activity {
    ImageView photoView;
    TextView status;
    Bitmap original, edited;
    static final int PICK = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        photoView = findViewById(R.id.photoView);
        status = findViewById(R.id.statusText);

        findViewById(R.id.selectButton).setOnClickListener(v -> pickPhoto());
        findViewById(R.id.brightButton).setOnClickListener(v -> brighten());
        findViewById(R.id.bwButton).setOnClickListener(v -> grayscale());
        findViewById(R.id.resetButton).setOnClickListener(v -> reset());
        findViewById(R.id.saveButton).setOnClickListener(v -> save());
        findViewById(R.id.textButton).setOnClickListener(v -> addText());
    }

    void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r,c,d);
        if (r == PICK && c == RESULT_OK && d != null) {
            try {
                original = MediaStore.Images.Media.getBitmap(getContentResolver(), d.getData());
                edited = original.copy(Bitmap.Config.ARGB_8888, true);
                show(); status.setText("Photo loaded. Choose an edit below.");
            } catch(Exception e) { status.setText("Could not open that photo."); }
        }
    }

    void show() { photoView.setImageBitmap(edited); }

    void brighten() {
        if (edited == null) return;
        Bitmap out = Bitmap.createBitmap(edited.getWidth(), edited.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint();
        ColorMatrix m = new ColorMatrix(new float[]{
            1,0,0,0,25, 0,1,0,0,25, 0,0,1,0,25, 0,0,0,1,0
        });
        p.setColorFilter(new ColorMatrixColorFilter(m)); c.drawBitmap(edited,0,0,p);
        edited=out; show(); status.setText("Brightness improved.");
    }

    void grayscale() {
        if (edited == null) return;
        Bitmap out = Bitmap.createBitmap(edited.getWidth(), edited.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out); Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
            .33f,.59f,.11f,0,0, .33f,.59f,.11f,0,0, .33f,.59f,.11f,0,0, 0,0,0,1,0
        })));
        c.drawBitmap(edited,0,0,p); edited=out; show(); status.setText("Black & white applied.");
    }

    void reset() {
        if (original != null) { edited=original.copy(Bitmap.Config.ARGB_8888,true); show(); status.setText("Edits reset."); }
    }

    void addText() {
        if (edited == null) return;
        final EditText input = new EditText(this); input.setHint("Enter text");
        new AlertDialog.Builder(this).setTitle("Add text").setView(input)
            .setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{
                Bitmap out=edited.copy(Bitmap.Config.ARGB_8888,true);
                Canvas c=new Canvas(out); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.WHITE); p.setTextSize(Math.max(36,out.getWidth()/15f)); p.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(input.getText().toString(),40,80,p); edited=out; show(); status.setText("Text added.");
            }).show();
    }

    void save() {
        if (edited == null) { status.setText("Choose a photo first."); return; }
        try {
            String name="Cashear_"+System.currentTimeMillis()+".jpg";
            OutputStream os=getContentResolver().openOutputStream(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI.buildUpon()
                    .appendQueryParameter("title",name).build());
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v=new android.content.ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME,name); v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
                v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Cashear Graphics");
                Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
                os=getContentResolver().openOutputStream(u);
            }
            edited.compress(Bitmap.CompressFormat.JPEG,95,os); os.close();
            status.setText("Saved to your gallery.");
            Toast.makeText(this,"Photo saved!",Toast.LENGTH_SHORT).show();
        } catch(Exception e) { status.setText("Save failed. Try again."); }
    }
}
